java -classpath ./botplayer:./"Java Library"/JavaClient.jar:./"Java Library"/* RunClient $@
